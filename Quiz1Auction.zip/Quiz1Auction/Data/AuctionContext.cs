using Quiz1Auction.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Quiz1Auction.Data
{
    public class AuctionContext : DbContext
    {
        public DbSet<Auction> Auctions {get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) 
        	{
            	optionsBuilder.UseSqlite(@"Data source=MyAuctions.sqlite");
        	}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
            {
                modelBuilder.ApplyConfiguration(new AuctionConfiguration());
            }
    }
}