using Quiz1Auction.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Quiz1Auction.Data
{
    public class AuctionConfiguration : IEntityTypeConfiguration<Auction>
    {
        public void Configure(EntityTypeBuilder<Auction> builder)
        		{
            			// Fluent API can be used here to specify additional requirements on entities
            			builder.Property(p => p.LastPrice).HasColumnName("LastPrice");
        		}
    }
}