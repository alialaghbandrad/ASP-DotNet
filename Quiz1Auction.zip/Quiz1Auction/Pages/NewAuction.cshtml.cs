using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
// Added
using Quiz1Auction.Models;
using Quiz1Auction.Data;

namespace Quiz1Auction.Pages
{
    
    public class NewAuctionModel : PageModel
    {
        private readonly AuctionContext db;
        public NewAuctionModel(AuctionContext db) {
            this.db = db;
        }

        [BindProperty]
        public Auction NewAuction { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            
            db.Auctions.Add(NewAuction);
            await db.SaveChangesAsync();

            return RedirectToPage("./NewAuctionSuccess");
        }
    }
}

// - form that creates a new auction with the following fields: Seller Email, Item Name, Item Description (textarea), Initial Price (becomes LastPrice).
// - form submission must verify values as specified above in comments of class Auction.
// - on successful submission a new record is created with Seller being the currently authenticated user and LastBidder being null.
