using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
// Added
using Quiz1Auction.Models;
using Quiz1Auction.Data;
using System.ComponentModel.DataAnnotations;

namespace Quiz1Auction.Pages
{
    public class AuctionModel : PageModel
    {
        private readonly AuctionContext db;
        public AuctionModel(AuctionContext db) => this.db = db;

        [BindProperty(SupportsGet = true)]
        public int Id { get; set; }

        [BindProperty]
        public Auction Auction { get; set; }
        public void OnGet()
        {
            Auction = db.Auctions.Find(Id);
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            } else {
            
                var AuctionFromDB = db.Auctions.FirstOrDefault(x => x.Id == Id);

                if (!(AuctionFromDB.LastPrice < Auction.LastPrice)) {
                    ModelState.AddModelError(string.Empty, "Auction update failed (the new bid must be higher than the old bid)");
                    
                } else {

                    AuctionFromDB.SellerEmail = Auction.SellerEmail;
                    AuctionFromDB.LastPrice = Auction.LastPrice;
                    await db.SaveChangesAsync();

                    return RedirectToPage("/AuctionBidSuccess");
                }
            }
            return Page();
        }
    }
}
