﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
//Added
using Quiz1Auction.Models;
using Quiz1Auction.Data;
using Microsoft.EntityFrameworkCore;

namespace Quiz1Auction.Pages
{
    public class IndexModel : PageModel
    {
        public List<Auction> AuctionsList { get; set; } = new List<Auction>();
        private readonly AuctionContext db;
        private readonly ILogger<IndexModel> _logger;

        public IndexModel(AuctionContext db, ILogger<IndexModel> logger)
        {
            this.db = db;
            _logger = logger;
        }

        public async Task OnGetAsync()
        {
            AuctionsList = await db.Auctions.ToListAsync();
        }
    }
}
