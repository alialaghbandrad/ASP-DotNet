using System.ComponentModel.DataAnnotations;
using System;

namespace Quiz1Auction.Models
{
    public class Auction
    {
        public int Id {get; set;}

        [Required]
        [EmailAddress]
        public string SellerEmail { get; set; }

        [Required, MinLength(1), MaxLength(100) ]
        public string ItemName {get; set;}

        [Required, MinLength(2), MaxLength(2000) ]
        public string ItemDescription {get; set;}

        [Required, Range(0, 9999999999)]
        public decimal LastPrice { get; set; }

        public string LastBidderEmail { get; set; }

    }
}