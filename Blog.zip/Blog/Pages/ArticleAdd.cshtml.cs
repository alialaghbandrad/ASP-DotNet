using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;
using Blog.Data;
using Microsoft.AspNetCore.Identity;
using Blog.Models;
using System.ComponentModel.DataAnnotations;
// added
using Microsoft.AspNetCore.Http;

namespace Blog.Pages
{
    [Authorize] // any authenticated user may access
    public class ArticleAddModel : PageModel
    {
        private readonly BlogDbContext db;
        private readonly UserManager<IdentityUser> userManager;
        private readonly SignInManager<IdentityUser> signInManager;
        public ArticleAddModel(BlogDbContext db, UserManager<IdentityUser> userManager, SignInManager<IdentityUser> signInManager) {
            this.db = db;
            this.userManager = userManager;
            this.signInManager = signInManager;
        }

        // [BindProperty]
        // public Article newArticle { get; set; }


        [BindProperty, Required, MinLength(1), MaxLength(200), Display(Name = "Title")]
        public string Title { get; set; }

        [BindProperty]
        public IFormFile Upload { get; set; }

        [BindProperty, Required, MinLength(1), MaxLength(20000), Display(Name = "Content")]
        public string Body { get; set; }

        // public void OnGet()
        // {
        // }
        
        public async Task<IActionResult> OnPostAsync()
        {
            if (ModelState.IsValid)
            {
                var userName = User.Identity.Name; // userName is email
                var user = db.Users.Where(u => u.UserName == userName).FirstOrDefault();
                var newArticle = new Blog.Models.Article { Title = Title, Body = Body, Author = user, Created = DateTime.Now };
                db.Articles.Add(newArticle);
                await db.SaveChangesAsync();
                return RedirectToPage("/Index");
            }
            
            return Page();
        }
        /*
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var user = User.Identity.Name; 
            Article.Author = db.Users.FirstOrDefault(u => u.UserName == user);   
            Article.Created = DateTime.Now;
            db.Articles.Add(Article);
            await db.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
        */
    }
}
